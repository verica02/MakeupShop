﻿using MakeupShop.Models;

namespace MakeupShop.ViewModels
{
    public class UserMakeupVM
    {
        public UserMakeup UserMakeup { get; set; }
        public int MakeupId { get; set; }
    }
}
