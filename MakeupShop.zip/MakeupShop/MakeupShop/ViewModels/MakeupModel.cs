﻿using MakeupShop.Models;

namespace MakeupShop.ViewModels
{
    public class MakeupModel
    {
        public Makeup Makeup { get; set; }
        public IFormFile Image { get; set; }
    }
}
