﻿using MakeupShop.Models;

namespace MakeupShop.ViewModels
{
    public class ReviewModel
    {
        public Review Review { get; set; }
        public int MakeupId { get; set; }
    }
}
