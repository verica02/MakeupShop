﻿using MakeupShop.Models;

namespace MakeupShop.ViewModels
{
    public class BrandModel
    {
        public Brand Brand { get; set; }
        public IFormFile Image { get; set; }
    }
}
